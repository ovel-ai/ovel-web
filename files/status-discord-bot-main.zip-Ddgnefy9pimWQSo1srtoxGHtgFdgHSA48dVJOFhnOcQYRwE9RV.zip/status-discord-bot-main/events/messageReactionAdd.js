module.exports = async (reaction, user) => {
    if (reaction.emoji === '💀') {
        console.log('yes');
    }
}