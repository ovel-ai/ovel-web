const Discord = require("discord.js")
const config = require("../config.json")
const axios = require("axios")

module.exports = async (client, member, guild) => {
    console.log(`${member.user.tag} has left.`)
    
            }
            
