# Table of contents

## Status Bot Config

* [Creating your first project](README.md)
* [Configurating the Bot](status-bot-config/configurating-the-bot.md)
* [Starting The Bot Up](status-bot-config/starting-the-bot-up.md)
