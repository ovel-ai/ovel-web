# Starting The Bot Up

{% hint style="warning" %}
NodeJS Version 16 + is Required to Run this Bot. Get NodeJS Here : [https://nodejs.org/](https://nodejs.org/en/)
{% endhint %}

### Installing the Required Packages

* [ ] Go to your Directory and Right Click and Click on "Open Powershell window here"

![Click the "Open Powershell Window here"](../.gitbook/assets/eKwc.png)

* [ ] Then Type in `npm i` in the powershell window

![Write npm i in the powershell window](../.gitbook/assets/KDLy.png)

* [ ] After all Packages are Downloaded Start the Bot with `node index.js` in the Powershell Window

![Write node index.js on Powershell](../.gitbook/assets/AWUj.png)

Your Bot should be Running Now! &#x20;
