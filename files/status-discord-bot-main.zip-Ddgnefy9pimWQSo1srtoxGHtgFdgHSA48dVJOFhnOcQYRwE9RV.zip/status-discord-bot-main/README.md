# Creating your first project

## The basics

#### First Of All you would Need a Bot&#x20;

* Go to the [Developers Portal](https://discord.com/developers/applications)
* Make an Application \
  \- ![](.gitbook/assets/G6bm.png)
* Scroll Down to Find **Bots**\
  \- ![](.gitbook/assets/YPcZ.png)



* Click On **Reset Token**

![The Reset Token should be Clicked as The Token is revealed only 1 Time.](.gitbook/assets/fgPr.png)

* Your Token Will Appear after the "Reset Token Process"

![Click on Copy then Put the token in the config file.](.gitbook/assets/s33b.png)
